﻿using DataAccessLayer;
using DataAccessLayer.Interfaces;
using DataAccessLayer.Models;
using DataAccessLayer.Repositories;
using System;
using System.Linq;

namespace ConsoleAplication
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var context = new DataContext())
            {
                IUserRepository userRepository = new UserRepository(context);

                // Додавання користувачів
                userRepository.Add(new User { Name = "John Doe", Email = "john@example.com" });
                userRepository.Add(new User { Name = "Jane Smith", Email = "jane@example.com" });
                userRepository.SaveChanges(); // Збереження змін

                // Отримання всіх користувачів
                var users = userRepository.GetAll();
                foreach (var user in users)
                {
                    Console.WriteLine($"Id: {user.Id}, Name: {user.Name}, Email: {user.Email}");
                }

                // Отримання користувача за Id
                var userById = userRepository.GetById(1);
                if (userById != null)
                {
                    Console.WriteLine($"\nUser with Id 1: Name: {userById.Name}, Email: {userById.Email}");
                }

                // Оновлення користувача
                var userToUpdate = userRepository.GetById(2);
                if (userToUpdate != null)
                {
                    userToUpdate.Email = "new_jane@example.com";
                    userRepository.Update(userToUpdate);
                    userRepository.SaveChanges();
                }

                // Видалення користувача
                userRepository.Delete(1);
                userRepository.SaveChanges();

                Console.WriteLine("\nUsers after delete:");
                users = userRepository.GetAll();
                foreach (var user in users)
                {
                    Console.WriteLine($"Id: {user.Id}, Name: {user.Name}, Email: {user.Email}");
                }
            }

            Console.ReadKey();
        }
    }
}